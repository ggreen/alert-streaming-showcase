package io.cloudnativedata.perfest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerfestApplication {

	public static void main(String[] args) {
		SpringApplication.run(PerfestApplication.class, args);
	}

}
