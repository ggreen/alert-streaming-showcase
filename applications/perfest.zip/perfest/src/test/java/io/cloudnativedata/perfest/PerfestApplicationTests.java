package io.cloudnativedata.perfest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfestApplicationTests {

	@Test
	void contextLoads() {
	}

}
